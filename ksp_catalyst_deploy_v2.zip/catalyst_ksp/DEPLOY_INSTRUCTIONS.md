# Deploying KSP Case Assistant to Zoho Catalyst

This package ports your Flask app (`app.py` + friends) into Catalyst's
**Advanced I/O Function** model, and rebuilds the frontend as a proper
login page + working sidebar dashboard, hosted as a Catalyst **Web Client**.

## What changed vs. your original Flask app, and why

Catalyst functions are stateless/serverless — there's no long-running Flask
process to hold `session`. Two things had to adapt:

1. **Auth**: `session["badge_no"]` → a signed bearer token. `/login` now
   returns a `token` (badge/name/role, HMAC-signed) instead of setting a
   cookie. The client stores it in `localStorage` and sends
   `Authorization: Bearer <token>` on every request. `main.py` verifies the
   signature — nothing is stored server-side.
2. **Routing**: `@app.route(...)` decorators → one `handler(request)` in
   `main.py` that dispatches on `request.path` / `request.method`, per
   Catalyst's Python function convention.

Everything else — `db.py`, `nlp.py`, `crime_trends.py`, `graph.py`,
`pdf_report.py`, `smart_suggestions.py`, `train_classifier.py` — is your
original logic, unchanged except `train_classifier.py`'s model path now
points at `/tmp` (the only writable path in the function runtime).

**Known limitation, same as your Render setup:** the SQLite DB lives in
`/tmp`, which is ephemeral — a cold start wipes it and `db.init_db()`
reseeds fresh mock data. Fine for a hackathon demo; for real persistence
you'd migrate `db.py` to Catalyst Data Store + ZCQL (happy to help with
that as a follow-up).

## Package layout

```
catalyst_ksp/
├── functions/
│   └── ksp_function/
│       ├── main.py              ← Advanced I/O function entry point
│       ├── db.py, nlp.py, crime_trends.py, graph.py,
│       │   pdf_report.py, smart_suggestions.py, train_classifier.py
│       └── requirements.txt
└── client/
    ├── index.html                ← login page (entry point)
    ├── dashboard.html            ← app shell + sidebar + all panels
    ├── main.css
    ├── main.js
    └── client-package.json
```

## 1. Prerequisites

- **Catalyst CLI**: `npm install -g zcatalyst-cli`, then `catalyst login`
- **Python 3.10–3.13** installed locally (for local testing — the deployed
  function runs in Catalyst's own Python runtime, you don't need to match
  versions exactly, just stay in that range)

## 2. Create the project in the console

1. Log in at [catalyst.zoho.com](https://catalyst.zoho.com) → **Create New Project** → name it e.g. `KSPCaseAssistant`.
2. Click **Access Project**.

## 3. Initialize locally and drop in the code

```bash
mkdir ksp-catalyst && cd ksp-catalyst
catalyst init
```

Walk through the prompts:
- Select your portal, then select the `KSPCaseAssistant` project.
- Select **Functions** (space bar) → Enter.
- Function type: **AdvancedIO**
- Stack: **Python 3.10** (or any 3.10–3.13 offered)
- Package name: `ksp_function`  ← **must match exactly** — `main.js` calls `/server/ksp_function/...`
- Entry point: `main.py`

This creates `functions/ksp_function/` with a starter `main.py`,
`catalyst-config.json`, and `requirements.txt`. **Replace its contents**
with the files from this package (keep the CLI-generated
`catalyst-config.json` as-is — it just needs `main.py` present as the
entry point, which it already points to).

Then set up the client:
```bash
catalyst client:setup
```
- Choose **Basic web app**
- Name it e.g. `ksp_client`

This creates a `client/` directory — replace its contents with the
`client/` files from this package.

Your final local tree should look like the layout above, sitting inside
`ksp-catalyst/`.

## 4. Set the auth secret

In the Catalyst console: **Functions → ksp_function → Environment
Variables** → add:

| Key | Value |
|---|---|
| `FUNCTION_SECRET` | any long random string — this signs login tokens |

Optional, same as your original app:

| Key | Value |
|---|---|
| `GEMINI_API_KEY` | your key from aistudio.google.com/apikey, only if you want Gemini prose rewrites |

## 5. Test locally

```bash
catalyst serve
```
This serves the function and client on a local port and prints the URLs.
Open the client URL, sign in with `SI001` / `demo123` (or any badge from
the demo table on the login page), and click through the sidebar tabs —
Heatmap, Graph, and Analytics fetch their data the first time you open
each tab.

## 6. Deploy

```bash
catalyst deploy
```
This deploys the function first, then the client, and prints both
production URLs. Open the client URL — that's your live demo link.

## 7. Sanity checklist if something doesn't load

- **Blank dashboard / redirected to login immediately**: check
  `localStorage` in devtools for `ksp_token` — if login didn't return one,
  check the Function logs in the console for the actual error.
- **404 on every API call**: confirm the function's package name is
  exactly `ksp_function` (case-sensitive) — it's hardcoded as
  `FUNCTION_BASE` in `main.js`. If you named it differently, update that
  one constant.
- **PDF download fails**: check that `reportlab` installed correctly —
  Catalyst installs `requirements.txt` at deploy time; check the deploy
  log for pip errors.
- **Login works but every tab shows "Not authenticated"**: `FUNCTION_SECRET`
  isn't set (or differs) in the console's environment variables — the
  token's signature won't verify without it.
