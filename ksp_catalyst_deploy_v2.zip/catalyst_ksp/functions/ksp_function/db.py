"""
db.py — SQLite schema + synthetic mock-data generator for the KSP Case Assistant prototype.

Every record here is randomly generated / fictional. No real case data, no real
national ID numbers, no real people. This exists purely so the AI features have
something realistic-shaped to query.
"""
import sqlite3
import random
import os
from datetime import date, timedelta

DB_PATH = os.path.join("/tmp", "ksp_prototype.db")

DISTRICTS = [
    ("Koramangala", 12.9352, 77.6245),
    ("Whitefield", 12.9698, 77.7500),
    ("Indiranagar", 12.9719, 77.6412),
    ("Jayanagar", 12.9250, 77.5938),
    ("Malleshwaram", 13.0037, 77.5695),
    ("Rajajinagar", 12.9911, 77.5525),
    ("Yelahanka", 13.1005, 77.5963),
    ("BTM Layout", 12.9166, 77.6101),
]

CRIME_TYPES = [
    "Theft", "Vehicle Theft", "Burglary", "Robbery", "Assault",
    "Cybercrime - Fraud", "Cybercrime - Phishing", "Missing Person",
    "Chain Snatching", "Domestic Dispute",
]

STATUSES = ["open", "under-investigation", "closed"]

FIRST_NAMES = ["Arjun", "Priya", "Rahul", "Sneha", "Vikram", "Anjali", "Karthik",
               "Divya", "Manoj", "Lakshmi", "Suresh", "Kavya", "Ravi", "Meena"]
LAST_NAMES = ["Rao", "Gowda", "Reddy", "Shetty", "Iyer", "Kumar", "Naik", "Patil"]

OFFICER_NAMES = [
    ("SI Nandini Rao", "Sub-Inspector"),
    ("SI Arjun Shetty", "Sub-Inspector"),
    ("Insp. Vikram Kumar", "Inspector"),
    ("Insp. Priya Iyer", "Inspector"),
    ("DySP Manoj Gowda", "Superintendent"),
]


def _random_name():
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def _random_date(start_days_ago=200, end_days_ago=0):
    d = date.today() - timedelta(days=random.randint(end_days_ago, start_days_ago))
    return d.isoformat()


def init_db(force=False):
    if force and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    first_time = not os.path.exists(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        badge_no TEXT UNIQUE,
        name TEXT,
        role TEXT,
        password TEXT
    );

    CREATE TABLE IF NOT EXISTS cases (
        id INTEGER PRIMARY KEY,
        crime_no TEXT UNIQUE,
        date TEXT,
        type TEXT,
        district TEXT,
        lat REAL,
        lng REAL,
        status TEXT,
        officer TEXT,
        victim_name TEXT,
        victim_gender TEXT,
        victim_age INTEGER,
        accused_name TEXT,
        brief_facts TEXT
    );

    CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY,
        case_id INTEGER,
        officer TEXT,
        note TEXT,
        created_at TEXT,
        FOREIGN KEY(case_id) REFERENCES cases(id)
    );
    """)

    if first_time:
        # Seed users — one per role, simple demo credentials
        roles = [
            ("C001", "Const. Ramesh Babu", "Constable", "demo123"),
            ("SI001", "SI Nandini Rao", "Sub-Inspector", "demo123"),
            ("IN001", "Insp. Vikram Kumar", "Inspector", "demo123"),
            ("ADMIN001", "DySP Manoj Gowda", "Superintendent", "demo123"),
        ]
        cur.executemany(
            "INSERT INTO users (badge_no, name, role, password) VALUES (?,?,?,?)",
            roles,
        )

        # Seed ~60 synthetic cases across 7 months for trend analytics
        rows = []
        for i in range(60):
            district, lat, lng = random.choice(DISTRICTS)
            crime_type = random.choice(CRIME_TYPES)
            status = random.choices(STATUSES, weights=[0.35, 0.30, 0.35])[0]
            officer, _ = random.choice(OFFICER_NAMES)
            gender = random.choice(["Male", "Female"])
            age = random.randint(18, 65)
            crime_no = f"FIR-2026-{1000 + i}"
            d = _random_date(210, 1)
            jitter_lat = lat + random.uniform(-0.01, 0.01)
            jitter_lng = lng + random.uniform(-0.01, 0.01)
            facts = (
                f"On {d}, a complaint of {crime_type.lower()} was registered at "
                f"{district} station. The victim, aged {age}, reported the incident "
                f"to {officer}. Case status is currently '{status}'."
            )
            rows.append((
                crime_no, d, crime_type, district, jitter_lat, jitter_lng, status,
                officer, _random_name(), gender, age, _random_name(), facts,
            ))
        cur.executemany(
            """INSERT INTO cases
               (crime_no, date, type, district, lat, lng, status, officer,
                victim_name, victim_gender, victim_age, accused_name, brief_facts)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            rows,
        )

        # A handful of seed officer notes
        cur.execute("SELECT id, officer FROM cases LIMIT 10")
        for case_id, officer in cur.fetchall():
            cur.execute(
                "INSERT INTO notes (case_id, officer, note, created_at) VALUES (?,?,?,?)",
                (case_id, officer, "Initial statement recorded; awaiting forensic report.",
                 _random_date(30, 1)),
            )

    conn.commit()
    conn.close()


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


if __name__ == "__main__":
    init_db(force=True)
    print(f"Database initialized at {DB_PATH}")
