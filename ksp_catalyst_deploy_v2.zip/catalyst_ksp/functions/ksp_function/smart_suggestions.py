"""
smart_suggestions.py — "Smart AI Suggestions" feature.

Note on honesty: this is a rule-based heuristic, not a learned recommender —
labeled that way in the UI too. For a hackathon demo it's the right scope;
a real version would log query/click history and rank by co-occurrence.
"""

def suggest_followups(explain_trace):
    entities = explain_trace.get("entities", {})
    intent = explain_trace.get("intent")
    suggestions = []

    if "district" in entities:
        suggestions.append(f"Show the crime trend for {entities['district']}")
    if "type" in entities:
        suggestions.append(f"Which districts have the most {entities['type']} cases?")
    if "status" not in entities:
        suggestions.append("Filter these to only open cases")
    if intent == "case_lookup":
        suggestions.append("Show related cases handled by the same officer")
    if not suggestions:
        suggestions = [
            "How many cases are currently open?",
            "Show the crime trend over the last 6 months",
            "Which case type is most common this month?",
        ]
    return suggestions[:3]
