"""
main.py — KSP Case Assistant, Catalyst Advanced I/O Function.

This is app.py ported to Catalyst's single-dispatcher function model.
Two things had to change from the original Flask app because Advanced I/O
functions are stateless/serverless — there's no long-running Flask app
object to hold server-side sessions:

  1. Auth: Flask `session` → a signed bearer token returned at login and
     sent back as `Authorization: Bearer <token>` on every request. The
     token carries badge_no/name/role, HMAC-signed with FUNCTION_SECRET so
     it can't be forged. Nothing is stored server-side.
  2. Routing: Flask's @app.route decorators → one handler(request) that
     dispatches on request.path / request.method, per Catalyst's Python
     Advanced I/O convention.

Everything else — db.py, nlp.py, crime_trends.py, graph.py, pdf_report.py,
smart_suggestions.py, train_classifier.py — is untouched business logic,
just called directly instead of through Flask routes.
"""
import os
import io
import json
import hmac
import base64
import hashlib
import logging
from datetime import datetime

from flask import Request, make_response, jsonify
import zcatalyst_sdk

import db
import nlp
import crime_trends
import graph as graphmod
import pdf_report
from smart_suggestions import suggest_followups

logger = logging.getLogger()

# Set this in the Catalyst console under Functions -> ksp_function -> Environment
# Variables. Never hardcode a real secret here.
FUNCTION_SECRET = os.environ.get("FUNCTION_SECRET", "dev-only-secret-change-me")

ROLE_TABS = {
    "Constable": ["copilot", "fir_summary", "notes", "heatmap"],
    "Sub-Inspector": ["copilot", "fir_summary", "notes", "heatmap", "graph"],
    "Inspector": ["copilot", "fir_summary", "notes", "heatmap", "graph", "pdf"],
    "Superintendent": ["copilot", "fir_summary", "notes", "heatmap", "graph", "pdf", "analytics"],
}


# ---------------- Token helpers (replaces Flask session) ----------------
def _sign(payload_b64: str) -> str:
    return hmac.new(FUNCTION_SECRET.encode(), payload_b64.encode(), hashlib.sha256).hexdigest()[:32]


def make_token(badge_no, name, role):
    payload = json.dumps({"badge_no": badge_no, "name": name, "role": role})
    payload_b64 = base64.urlsafe_b64encode(payload.encode()).decode()
    return f"{payload_b64}.{_sign(payload_b64)}"


def verify_token(token):
    try:
        payload_b64, sig = token.split(".")
        if not hmac.compare_digest(sig, _sign(payload_b64)):
            return None
        return json.loads(base64.urlsafe_b64decode(payload_b64.encode()).decode())
    except Exception:
        return None


def _auth_user(request):
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    return verify_token(header[7:])


def _check_tab_access(request, tab):
    user = _auth_user(request)
    if not user:
        return None, (jsonify({"error": "Not authenticated"}), 401)
    if tab not in ROLE_TABS.get(user["role"], []):
        return None, (jsonify({"error": f"Your role ({user['role']}) doesn't have access to this feature"}), 403)
    return user, None


def _json(request):
    return request.get_json(silent=True) or {}


def _path_after(request, prefix):
    """e.g. prefix='/api/case/' on '/api/case/FIR-2026-1000' -> 'FIR-2026-1000'"""
    return request.path[len(prefix):] if request.path.startswith(prefix) else None


# ---------------------------- Main dispatcher ----------------------------
def handler(request: Request):
    try:
        zcatalyst_sdk.initialize()  # available if you later move data into Catalyst Data Store
        if not os.path.exists(db.DB_PATH):
            db.init_db()

        path = request.path
        method = request.method

        # ---- Login ----
        if path == "/login" and method == "POST":
            data = _json(request)
            badge_no = (data.get("badge_no") or "").strip().upper()
            password = data.get("password") or ""

            conn = db.get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE badge_no = ?", (badge_no,))
            user = cur.fetchone()
            conn.close()

            if not user or user["password"] != password:
                return make_response(jsonify({"ok": False, "error": "Invalid badge number or password"}), 401)

            token = make_token(user["badge_no"], user["name"], user["role"])
            return make_response(jsonify({
                "ok": True,
                "token": token,
                "name": user["name"],
                "role": user["role"],
                "tabs": ROLE_TABS.get(user["role"], ["copilot"]),
            }), 200)

        # ---- Copilot ----
        if path == "/api/copilot" and method == "POST":
            user, err = _check_tab_access(request, "copilot")
            if err:
                return make_response(*err)
            question = (_json(request).get("question") or "").strip()
            if not question:
                return make_response(jsonify({"error": "Question is required"}), 400)

            result = nlp.run_query(question)
            gemini_text = nlp.answer_with_gemini(question, result)
            if gemini_text:
                result["answer"] = gemini_text
                result["explain"]["gemini_used"] = True
            else:
                result["explain"]["gemini_used"] = False
            result["suggestions"] = suggest_followups(result["explain"])
            return make_response(jsonify(result), 200)

        # ---- FIR summary: GET /api/case/<crime_no> ----
        crime_no = _path_after(request, "/api/case/")
        if crime_no and method == "GET":
            user, err = _check_tab_access(request, "fir_summary")
            if err:
                return make_response(*err)

            conn = db.get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM cases WHERE crime_no = ?", (crime_no.upper(),))
            case = cur.fetchone()
            if not case:
                conn.close()
                return make_response(jsonify({"error": "Case not found"}), 404)
            case = dict(case)
            cur.execute("SELECT * FROM notes WHERE case_id = ? ORDER BY created_at DESC", (case["id"],))
            notes = [dict(r) for r in cur.fetchall()]
            conn.close()

            summary = (
                f"Case {case['crime_no']} is a {case['type']} matter reported on {case['date']} "
                f"in {case['district']}, currently {case['status']}. The victim "
                f"({case['victim_gender']}, age {case['victim_age']}) reported the incident to "
                f"{case['officer']}. {len(notes)} officer note(s) on file. {case['brief_facts']}"
            )
            return make_response(jsonify({"case": case, "notes": notes, "summary": summary}), 200)

        # ---- Heatmap ----
        if path == "/api/heatmap" and method == "GET":
            user, err = _check_tab_access(request, "heatmap")
            if err:
                return make_response(*err)
            conn = db.get_conn()
            cur = conn.cursor()
            cur.execute("SELECT crime_no, type, status, district, lat, lng FROM cases")
            rows = [dict(r) for r in cur.fetchall()]
            conn.close()
            return make_response(jsonify(rows), 200)

        # ---- Relationship graph ----
        if path == "/api/graph" and method == "GET":
            user, err = _check_tab_access(request, "graph")
            if err:
                return make_response(*err)
            return make_response(jsonify(graphmod.build_relationship_graph()), 200)

        # ---- Analytics ----
        if path == "/api/analytics" and method == "GET":
            user, err = _check_tab_access(request, "analytics")
            if err:
                return make_response(*err)
            return make_response(jsonify({
                "monthly": crime_trends.monthly_counts(),
                "by_type": crime_trends.counts_by_type(),
                "by_district": crime_trends.counts_by_district(),
                "by_status": crime_trends.status_breakdown(),
            }), 200)

        # ---- Notes: GET/POST /api/notes/<crime_no> ----
        note_crime_no = _path_after(request, "/api/notes/")
        if note_crime_no and method in ("GET", "POST"):
            user, err = _check_tab_access(request, "notes")
            if err:
                return make_response(*err)

            conn = db.get_conn()
            cur = conn.cursor()
            cur.execute("SELECT id FROM cases WHERE crime_no = ?", (note_crime_no.upper(),))
            case = cur.fetchone()
            if not case:
                conn.close()
                return make_response(jsonify({"error": "Case not found"}), 404)
            case_id = case["id"]

            if method == "POST":
                note_text = (_json(request).get("note") or "").strip()
                if not note_text:
                    conn.close()
                    return make_response(jsonify({"error": "Note text required"}), 400)
                cur.execute(
                    "INSERT INTO notes (case_id, officer, note, created_at) VALUES (?,?,?,?)",
                    (case_id, user["name"], note_text, datetime.now().isoformat(timespec="minutes")),
                )
                conn.commit()

            cur.execute("SELECT * FROM notes WHERE case_id = ? ORDER BY created_at DESC", (case_id,))
            notes = [dict(r) for r in cur.fetchall()]
            conn.close()
            return make_response(jsonify(notes), 200)

        # ---- PDF report: GET /api/pdf/<crime_no> ----
        pdf_crime_no = _path_after(request, "/api/pdf/")
        if pdf_crime_no and method == "GET":
            user, err = _check_tab_access(request, "pdf")
            if err:
                return make_response(*err)

            conn = db.get_conn()
            cur = conn.cursor()
            cur.execute("SELECT * FROM cases WHERE crime_no = ?", (pdf_crime_no.upper(),))
            case = cur.fetchone()
            if not case:
                conn.close()
                return make_response(jsonify({"error": "Case not found"}), 404)
            case = dict(case)
            cur.execute("SELECT * FROM notes WHERE case_id = ? ORDER BY created_at DESC", (case["id"],))
            notes = [dict(r) for r in cur.fetchall()]
            conn.close()

            buf = pdf_report.generate_case_pdf(case, notes)
            response = make_response(buf.getvalue(), 200)
            response.headers["Content-Type"] = "application/pdf"
            response.headers["Content-Disposition"] = f"attachment; filename={case['crime_no']}_report.pdf"
            return response

        return make_response(jsonify({"error": "Not found"}), 404)

    except Exception as err:
        logger.error(f"Exception in ksp_function: {err}")
        return make_response(jsonify({"error": "Internal server error occurred. Please try again in some time."}), 500)
