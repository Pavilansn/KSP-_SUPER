"""graph.py — builds the Officer/Case/Accused/Victim relationship network."""
import networkx as nx
from db import get_conn


def build_relationship_graph(limit=40):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM cases ORDER BY date DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    G = nx.Graph()
    for c in rows:
        case_node = f"case:{c['crime_no']}"
        officer_node = f"officer:{c['officer']}"
        accused_node = f"accused:{c['accused_name']}"
        victim_node = f"victim:{c['victim_name']}"

        G.add_node(case_node, label=c["crime_no"], kind="case", status=c["status"])
        G.add_node(officer_node, label=c["officer"], kind="officer")
        G.add_node(accused_node, label=c["accused_name"], kind="accused")
        G.add_node(victim_node, label=c["victim_name"], kind="victim")

        G.add_edge(officer_node, case_node, relation="handles")
        G.add_edge(accused_node, case_node, relation="accused_in")
        G.add_edge(victim_node, case_node, relation="victim_in")

    nodes = [{"id": n, "label": d["label"], "kind": d["kind"]} for n, d in G.nodes(data=True)]
    edges = [{"source": u, "target": v, "relation": d["relation"]} for u, v, d in G.edges(data=True)]
    return {"nodes": nodes, "edges": edges}
