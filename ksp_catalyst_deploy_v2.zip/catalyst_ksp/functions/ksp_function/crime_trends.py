"""crime_trends.py — aggregation queries backing the Analytics tab."""
from db import get_conn


def monthly_counts():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT date, type, status, district FROM cases")
    rows = cur.fetchall()
    conn.close()

    by_month = {}
    for r in rows:
        month = r["date"][:7]  # YYYY-MM
        by_month.setdefault(month, 0)
        by_month[month] += 1
    months = sorted(by_month.keys())
    return {"labels": months, "values": [by_month[m] for m in months]}


def counts_by_type():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT type, COUNT(*) as n FROM cases GROUP BY type ORDER BY n DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"labels": [r["type"] for r in rows], "values": [r["n"] for r in rows]}


def counts_by_district():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT district, COUNT(*) as n FROM cases GROUP BY district ORDER BY n DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"labels": [r["district"] for r in rows], "values": [r["n"] for r in rows]}


def status_breakdown():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT status, COUNT(*) as n FROM cases GROUP BY status")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {"labels": [r["status"] for r in rows], "values": [r["n"] for r in rows]}
