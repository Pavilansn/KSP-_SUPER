"""
nlp.py — the "AI Investigation Copilot" brain.

Pipeline for every question:
  1. Classify intent with the trained model (train_classifier.py)
  2. Extract entities via keyword matching (district, crime type, gender, status, crime_no)
  3. Turn that into a filtered SQL query against the cases table
  4. Return results + a full explainability trace (what was matched and why)

Offline by default — zero external API calls. If GEMINI_API_KEY is set in the
environment, answer_with_gemini() can optionally rewrite the final answer in
nicer prose using Google's Generative Language API, but every filter/result is
still computed locally first — Gemini never sees or touches raw DB access.
"""
import os
import re
import json
import pickle
import urllib.request

from db import get_conn, DISTRICTS, CRIME_TYPES, STATUSES
from train_classifier import MODEL_PATH, train_and_save

CONFIDENCE_FLOOR = 0.35  # below this, keyword rules override the model's guess

_model = None


def _load_model():
    global _model
    if _model is None:
        if not os.path.exists(MODEL_PATH):
            _model = train_and_save()
        else:
            with open(MODEL_PATH, "rb") as f:
                _model = pickle.load(f)
    return _model


def _extract_entities(question):
    q = question.lower()
    entities = {}

    for name, _, _ in DISTRICTS:
        if name.lower() in q:
            entities["district"] = name
            break

    for ctype in CRIME_TYPES:
        # match on the leading keyword of multi-word types too (e.g. "phishing")
        for token in [ctype.lower()] + ctype.lower().split(" - "):
            if token and token in q:
                entities["type"] = ctype
                break
        if "type" in entities:
            break

    for status in STATUSES:
        if status.replace("-", " ") in q or status in q:
            entities["status"] = status
    if "unresolved" in q or "pending" in q:
        entities["status"] = "open"

    if any(w in q for w in ["female", "woman", "women", "lady", "girl"]):
        entities["gender"] = "Female"
    elif any(w in q for w in ["male", "man", "men", "boy"]) and "female" not in q:
        entities["gender"] = "Male"

    m = re.search(r"fir-\d{4}-\d+", q)
    if m:
        entities["crime_no"] = m.group(0).upper()

    return entities


def classify(question):
    model = _load_model()
    probs = model.predict_proba([question])[0]
    classes = model.classes_
    best_idx = probs.index(max(probs))
    intent, confidence = classes[best_idx], float(probs[best_idx])

    entities = _extract_entities(question)

    # Keyword-based safety net: if the model is unsure, let extracted entities
    # decide the intent instead. This is what keeps a 30-example model usable.
    rule_override = None
    if confidence < CONFIDENCE_FLOOR:
        if "crime_no" in entities:
            rule_override = "case_lookup"
        elif "district" in entities and "type" not in entities:
            rule_override = "filter_district"
        elif "type" in entities:
            rule_override = "filter_type"
        elif "gender" in entities:
            rule_override = "filter_gender"
        elif "status" in entities:
            rule_override = "filter_status"

    final_intent = rule_override or intent
    return {
        "intent": final_intent,
        "model_intent": intent,
        "model_confidence": round(confidence, 3),
        "rule_override_used": rule_override is not None,
        "entities": entities,
    }


def run_query(question):
    """Full pipeline: classify -> build SQL -> execute -> explain."""
    trace = classify(question)
    entities = trace["entities"]
    intent = trace["intent"]

    conn = get_conn()
    cur = conn.cursor()

    where, params = [], []
    if "district" in entities:
        where.append("district = ?"); params.append(entities["district"])
    if "type" in entities:
        where.append("type = ?"); params.append(entities["type"])
    if "status" in entities:
        where.append("status = ?"); params.append(entities["status"])
    if "gender" in entities:
        where.append("victim_gender = ?"); params.append(entities["gender"])
    if "crime_no" in entities:
        where.append("crime_no = ?"); params.append(entities["crime_no"])

    where_clause = (" WHERE " + " AND ".join(where)) if where else ""

    count_sql = "SELECT COUNT(*) as n FROM cases" + where_clause
    cur.execute(count_sql, params)
    total_count = cur.fetchone()["n"]

    sql = "SELECT * FROM cases" + where_clause + " ORDER BY date DESC LIMIT 25"
    cur.execute(sql, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()

    is_count_question = "how many" in question.lower() or "count of" in question.lower() or "total number" in question.lower()

    # Compose a plain-language answer locally (no API needed)
    if intent == "count_status" or is_count_question:
        answer = f"There are {total_count} case(s) matching that."
    elif intent == "case_lookup":
        if rows:
            c = rows[0]
            answer = (f"{c['crime_no']} — {c['type']} at {c['district']}, filed {c['date']}. "
                      f"Status: {c['status']}. Handling officer: {c['officer']}. "
                      f"{c['brief_facts']}")
        else:
            answer = "No case found with that crime number."
    elif not rows:
        answer = "No matching case records found for that query."
    else:
        shown_note = " (showing the 25 most recent)" if total_count > 25 else ""
        answer = f"Found {total_count} matching case(s){shown_note}."

    trace["sql"] = sql
    trace["sql_params"] = params
    trace["result_count"] = len(rows)
    trace["total_matching"] = total_count

    return {
        "answer": answer,
        "results": rows,
        "explain": trace,
    }


def answer_with_gemini(question, local_result):
    """Optional: rewrite the locally-computed answer in nicer prose via Gemini.
    Only called if GEMINI_API_KEY is set. Never sends the raw database — only
    the already-filtered result rows (max 25) as context."""
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return None

    context = json.dumps(local_result["results"][:25], indent=2, default=str)
    prompt = (
        "You are a police case assistant. Using ONLY the JSON case records below, "
        "answer the officer's question in 2-4 concise sentences. Do not invent facts.\n\n"
        f"QUESTION: {question}\n\nRECORDS:\n{context}"
    )
    body = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode()
    url = ("https://generativelanguage.googleapis.com/v1beta/models/"
           f"gemini-2.0-flash:generateContent?key={api_key}")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"(Gemini rewrite unavailable: {e})"
