"""
train_classifier.py — trains a small, real (not hardcoded) intent classifier
on synthetic example queries, entirely offline. No external API calls.

This is intentionally lightweight for a hackathon prototype. It used to be
TF-IDF + Logistic Regression via scikit-learn, but scikit-learn drags in
scipy + numpy, which bloated the Catalyst deployment package past the
platform's upload size limit. This version does the same job — TF-IDF
vectors + nearest-centroid cosine similarity, turned into softmax
pseudo-probabilities — using only the Python standard library, so the
deployed function stays small. Same public interface (MODEL_PATH,
train_and_save()) so nlp.py barely changed.

It's a genuine trained model, but the dataset is small, so a keyword-based
fallback in nlp.py covers cases the model is unsure about (see
CONFIDENCE_FLOOR there).
"""
import os
import re
import math
import pickle
from collections import Counter, defaultdict

MODEL_PATH = os.path.join("/tmp", "intent_model.pkl")

TRAINING_DATA = [
    # intent: count_status
    ("how many cases are open", "count_status"),
    ("how many cases are closed", "count_status"),
    ("count of cases under investigation", "count_status"),
    ("total number of open cases", "count_status"),
    ("how many closed cases do we have", "count_status"),
    ("give me the count of pending cases", "count_status"),

    # intent: filter_district
    ("show me cases in whitefield", "filter_district"),
    ("list all cases from koramangala station", "filter_district"),
    ("cases reported in indiranagar", "filter_district"),
    ("what cases happened in jayanagar", "filter_district"),
    ("show incidents in malleshwaram", "filter_district"),
    ("cases filed at yelahanka station", "filter_district"),

    # intent: filter_type
    ("show me all theft cases", "filter_type"),
    ("list burglary cases", "filter_type"),
    ("any cybercrime fraud cases this month", "filter_type"),
    ("show vehicle theft reports", "filter_type"),
    ("list all robbery cases", "filter_type"),
    ("show missing person cases", "filter_type"),
    ("phishing complaints filed recently", "filter_type"),

    # intent: filter_gender
    ("murder of a lady", "filter_gender"),
    ("cases where the victim is female", "filter_gender"),
    ("show cases involving male victims", "filter_gender"),
    ("crimes against women", "filter_gender"),
    ("female victim theft cases", "filter_gender"),

    # intent: filter_status
    ("show open cases", "filter_status"),
    ("list all closed cases", "filter_status"),
    ("cases still under investigation", "filter_status"),
    ("which cases are unresolved", "filter_status"),

    # intent: case_lookup
    ("summarize case fir-2026-1004", "case_lookup"),
    ("details for FIR-2026-1010", "case_lookup"),
    ("what happened in case fir-2026-1022", "case_lookup"),
    ("pull up crime number fir-2026-1035", "case_lookup"),

    # intent: trend_query
    ("show crime trend over the last few months", "trend_query"),
    ("how has theft changed month over month", "trend_query"),
    ("plot case volume by month", "trend_query"),
    ("which district has the most crime this year", "trend_query"),
    ("show monthly trend of cybercrime", "trend_query"),

    # intent: descriptive (open-ended / RAG-style)
    ("what patterns do you see in recent thefts", "descriptive"),
    ("summarize overall crime activity", "descriptive"),
    ("give me an overview of case statuses", "descriptive"),
    ("what should officers focus on this week", "descriptive"),
    ("any unusual activity recently", "descriptive"),
]


def _tokenize(text):
    """Lowercase, strip punctuation, and emit unigrams + bigrams — a cheap
    stand-in for TfidfVectorizer(ngram_range=(1, 2))."""
    text = re.sub(r"[^a-z0-9\s-]", " ", text.lower())
    words = text.split()
    tokens = list(words)
    tokens += [f"{a}_{b}" for a, b in zip(words, words[1:])]
    return tokens


class TinyIntentClassifier:
    """Nearest-centroid classifier over TF-IDF vectors, stdlib only.
    predict_proba() returns softmax-scaled cosine similarities so the
    output shape/semantics match what nlp.py expects from a real model."""

    def __init__(self):
        self.idf = {}
        self.centroids = {}
        self.classes_ = []

    def fit(self, texts, labels):
        docs_tokens = [_tokenize(t) for t in texts]

        df = defaultdict(int)
        for toks in docs_tokens:
            for term in set(toks):
                df[term] += 1
        n = len(texts)
        self.idf = {term: math.log((n + 1) / (freq + 1)) + 1 for term, freq in df.items()}

        vectors = [self._vectorize(toks) for toks in docs_tokens]

        by_label = defaultdict(list)
        for vec, label in zip(vectors, labels):
            by_label[label].append(vec)

        self.classes_ = sorted(by_label.keys())
        for label in self.classes_:
            self.centroids[label] = self._normalize(self._average(by_label[label]))

    def _vectorize(self, tokens):
        counts = Counter(tokens)
        vec = {t: c * self.idf.get(t, 0.0) for t, c in counts.items()}
        return self._normalize(vec)

    @staticmethod
    def _normalize(vec):
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        return {k: v / norm for k, v in vec.items()}

    @staticmethod
    def _average(vecs):
        summed = defaultdict(float)
        for vec in vecs:
            for k, v in vec.items():
                summed[k] += v
        n = len(vecs) or 1
        return {k: v / n for k, v in summed.items()}

    @staticmethod
    def _similarity(vec, centroid):
        return sum(v * centroid.get(k, 0.0) for k, v in vec.items())

    def predict_proba(self, texts):
        """Returns a list (one per input text) of plain Python lists of
        floats, aligned with self.classes_ — same shape as sklearn's
        predict_proba, just without numpy arrays."""
        results = []
        for text in texts:
            vec = self._vectorize(_tokenize(text))
            sims = [self._similarity(vec, self.centroids[label]) for label in self.classes_]
            temp = 6.0  # sharpens the softmax so a clear match gets high confidence
            scaled = [s * temp for s in sims]
            m = max(scaled)
            exps = [math.exp(s - m) for s in scaled]
            total = sum(exps) or 1.0
            results.append([e / total for e in exps])
        return results


def train_and_save():
    texts = [t for t, _ in TRAINING_DATA]
    labels = [l for _, l in TRAINING_DATA]

    clf = TinyIntentClassifier()
    clf.fit(texts, labels)

    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(clf, f)
    print(f"Trained intent classifier on {len(texts)} examples -> {MODEL_PATH}")
    return clf


if __name__ == "__main__":
    train_and_save()

