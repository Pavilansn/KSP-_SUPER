"""pdf_report.py — generates a one-page case file PDF via reportlab."""
import io
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                 TableStyle)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def generate_case_pdf(case, notes):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=20 * mm, bottomMargin=20 * mm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleBrass", parent=styles["Title"], textColor=colors.HexColor("#7c1a3d"))
    heading_style = ParagraphStyle("Heading", parent=styles["Heading2"], spaceBefore=12)

    story = []
    story.append(Paragraph("Karnataka State Police — Case File Report", title_style))
    story.append(Paragraph(f"Crime Number: {case['crime_no']}", styles["Normal"]))
    story.append(Spacer(1, 10))

    table_data = [
        ["Date Filed", case["date"]],
        ["Type", case["type"]],
        ["District / Station", case["district"]],
        ["Status", case["status"]],
        ["Handling Officer", case["officer"]],
        ["Victim", f"{case['victim_name']} ({case['victim_gender']}, {case['victim_age']})"],
        ["Accused", case["accused_name"]],
    ]
    tbl = Table(table_data, colWidths=[140, 320])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f3ecfb")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#c9a227")),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 16))

    story.append(Paragraph("Brief Facts", heading_style))
    story.append(Paragraph(case["brief_facts"], styles["Normal"]))

    story.append(Paragraph("Officer Notes", heading_style))
    if notes:
        for n in notes:
            story.append(Paragraph(f"<b>{n['created_at']} — {n['officer']}:</b> {n['note']}", styles["Normal"]))
            story.append(Spacer(1, 4))
    else:
        story.append(Paragraph("No notes recorded.", styles["Normal"]))

    story.append(Spacer(1, 20))
    story.append(Paragraph(
        "This is a prototype-generated report using synthetic demo data. Not a real police record.",
        ParagraphStyle("Footer", parent=styles["Normal"], textColor=colors.grey, fontSize=8)
    ))

    doc.build(story)
    buf.seek(0)
    return buf
