// ==========================================================================
// main.js — shared by index.html (login) and dashboard.html (app shell).
// FUNCTION_BASE points at the deployed Advanced I/O function. Catalyst
// exposes every function at /server/<function_package_name> once deployed.
// If you named your function directory something other than "ksp_function"
// when running `catalyst init`, update the path below to match.
// ==========================================================================
const FUNCTION_BASE = "/server/ksp_function";

const TAB_META = {
  copilot:      { label: "Copilot",        title: "Copilot",           sub: "Ask questions about case records in plain English.",
                  icon: '<path d="M3 5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H9l-4 3v-3H5a2 2 0 0 1-2-2V5Z" fill="none" stroke="currentColor" stroke-width="1.5"/>' },
  fir_summary:  { label: "FIR Summary",    title: "FIR Summary",       sub: "Plain-language summary of a case record.",
                  icon: '<path d="M6 2h6l4 4v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Z" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M12 2v4h4" fill="none" stroke="currentColor" stroke-width="1.5"/>' },
  notes:        { label: "Officer Notes",  title: "Officer Notes",     sub: "Add and review free-text notes on a case.",
                  icon: '<path d="M4 4h12v14l-4-3H4Z" fill="none" stroke="currentColor" stroke-width="1.5"/>' },
  heatmap:      { label: "Heatmap",        title: "Crime Heatmap",     sub: "Geospatial view of all case locations.",
                  icon: '<path d="M10 2C6.7 2 4 4.7 4 8c0 4.5 6 10 6 10s6-5.5 6-10c0-3.3-2.7-6-6-6Z" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="8" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/>' },
  graph:        { label: "Network Graph",  title: "Relationship Graph", sub: "Officers, cases, accused and victims linked together.",
                  icon: '<circle cx="5" cy="5" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="15" cy="5" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="15" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M6.5 6 9 13M13.5 6 11 13M7 5h6" stroke="currentColor" stroke-width="1.2"/>' },
  analytics:    { label: "Analytics",      title: "Crime Trend Analytics", sub: "Monthly, by-type, by-district and by-status breakdowns.",
                  icon: '<path d="M4 16V9M9 16V4M14 16v-6M4 16h12" fill="none" stroke="currentColor" stroke-width="1.5"/>' },
  pdf:          { label: "PDF Report",     title: "PDF Case Report",   sub: "Export a one-page case file report.",
                  icon: '<path d="M6 2h6l4 4v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Z" fill="none" stroke="currentColor" stroke-width="1.5"/><text x="6" y="15" font-size="6" fill="currentColor">PDF</text>' },
};

function authFetch(path, opts = {}) {
  const token = localStorage.getItem("ksp_token");
  opts.headers = Object.assign({}, opts.headers, { Authorization: "Bearer " + token });
  return fetch(FUNCTION_BASE + path, opts);
}

// ---------------- Only runs on dashboard.html ----------------
if (document.getElementById("navList")) {
  const token = localStorage.getItem("ksp_token");
  if (!token) {
    window.location.href = "index.html";
  } else {
    initDashboard();
  }
}

function initDashboard() {
  const name = localStorage.getItem("ksp_name");
  const role = localStorage.getItem("ksp_role");
  const tabs = JSON.parse(localStorage.getItem("ksp_tabs") || "[]");

  document.getElementById("chipName").textContent = name;
  document.getElementById("chipRole").textContent = role;

  const navList = document.getElementById("navList");
  tabs.forEach((tab, i) => {
    const meta = TAB_META[tab];
    if (!meta) return;
    const btn = document.createElement("button");
    btn.className = "nav-item" + (i === 0 ? " active" : "");
    btn.dataset.tab = tab;
    btn.innerHTML = `<svg viewBox="0 0 20 20">${meta.icon}</svg><span>${meta.label}</span>`;
    btn.addEventListener("click", () => switchTab(tab));
    navList.appendChild(btn);
  });

  if (tabs.length) switchTab(tabs[0]);

  document.getElementById("logoutBtn").addEventListener("click", () => {
    localStorage.clear();
    window.location.href = "index.html";
  });

  wirePanelHandlers();
}

const loadedPanels = new Set();

function switchTab(tab) {
  document.querySelectorAll(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.tab === tab));
  document.querySelectorAll(".panel").forEach(el => el.classList.toggle("active", el.dataset.panel === tab));
  const meta = TAB_META[tab];
  if (meta) {
    document.getElementById("pageTitle").textContent = meta.title;
    document.getElementById("pageSub").textContent = meta.sub;
  }
  // Lazy-load data-heavy panels once, on first visit
  if (!loadedPanels.has(tab)) {
    loadedPanels.add(tab);
    if (tab === "heatmap") loadHeatmap();
    if (tab === "graph") loadGraph();
    if (tab === "analytics") loadAnalytics();
  }
}

function statusPillHtml(status) {
  return `<span class="status-pill ${status}">${status}</span>`;
}

function wirePanelHandlers() {
  // ---------- Copilot ----------
  document.getElementById("copilotBtn").addEventListener("click", runCopilot);
  document.getElementById("copilotInput").addEventListener("keydown", e => { if (e.key === "Enter") runCopilot(); });

  async function runCopilot() {
    const q = document.getElementById("copilotInput").value.trim();
    if (!q) return;
    document.getElementById("copilotEmpty").classList.add("hidden");
    try {
      const res = await authFetch("/api/copilot", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: q })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");

      document.getElementById("copilotAnswerWrap").classList.remove("hidden");
      document.getElementById("copilotAnswer").textContent = data.answer;
      document.getElementById("copilotExplain").textContent = JSON.stringify(data.explain, null, 2);

      const chipsEl = document.getElementById("copilotChips");
      chipsEl.innerHTML = "";
      (data.suggestions || []).forEach(s => {
        const chip = document.createElement("button");
        chip.className = "btn-ghost";
        chip.textContent = s;
        chip.addEventListener("click", () => { document.getElementById("copilotInput").value = s; runCopilot(); });
        chipsEl.appendChild(chip);
      });

      const table = document.getElementById("copilotTable");
      const tbody = table.querySelector("tbody");
      tbody.innerHTML = "";
      if (data.results && data.results.length) {
        table.classList.remove("hidden");
        data.results.slice(0, 25).forEach(r => {
          const tr = document.createElement("tr");
          tr.innerHTML = `<td>${r.crime_no}</td><td>${r.type}</td><td>${r.district}</td><td>${r.date}</td><td>${statusPillHtml(r.status)}</td>`;
          tbody.appendChild(tr);
        });
      } else {
        table.classList.add("hidden");
      }
    } catch (err) {
      document.getElementById("copilotAnswerWrap").classList.remove("hidden");
      document.getElementById("copilotAnswer").innerHTML = `<span class="msg-error">${err.message}</span>`;
    }
  }

  // ---------- FIR summary ----------
  document.getElementById("firBtn").addEventListener("click", loadFir);
  async function loadFir() {
    const crimeNo = document.getElementById("firInput").value.trim();
    const wrap = document.getElementById("firResult");
    if (!crimeNo) return;
    wrap.innerHTML = `<div class="msg-empty">Loading…</div>`;
    try {
      const res = await authFetch(`/api/case/${encodeURIComponent(crimeNo)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Not found");
      const c = data.case;
      wrap.innerHTML = `
        <div class="answer-box">${data.summary}</div>
        <table class="data-table">
          <tr><th>District</th><td>${c.district}</td></tr>
          <tr><th>Status</th><td>${statusPillHtml(c.status)}</td></tr>
          <tr><th>Officer</th><td>${c.officer}</td></tr>
          <tr><th>Victim</th><td>${c.victim_name} (${c.victim_gender}, ${c.victim_age})</td></tr>
          <tr><th>Accused</th><td>${c.accused_name}</td></tr>
        </table>`;
    } catch (err) {
      wrap.innerHTML = `<div class="msg-error">${err.message}</div>`;
    }
  }

  // ---------- Notes ----------
  document.getElementById("notesLoadBtn").addEventListener("click", loadNotes);
  document.getElementById("noteAddBtn").addEventListener("click", addNote);

  async function loadNotes() {
    const crimeNo = document.getElementById("notesCrimeNo").value.trim();
    const listEl = document.getElementById("notesList");
    if (!crimeNo) return;
    listEl.innerHTML = `<div class="msg-empty">Loading…</div>`;
    try {
      const res = await authFetch(`/api/notes/${encodeURIComponent(crimeNo)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Not found");
      renderNotes(data);
    } catch (err) {
      listEl.innerHTML = `<div class="msg-error">${err.message}</div>`;
    }
  }

  async function addNote() {
    const crimeNo = document.getElementById("notesCrimeNo").value.trim();
    const note = document.getElementById("noteText").value.trim();
    if (!crimeNo || !note) return;
    try {
      const res = await authFetch(`/api/notes/${encodeURIComponent(crimeNo)}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ note })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not add note");
      document.getElementById("noteText").value = "";
      renderNotes(data);
    } catch (err) {
      document.getElementById("notesList").innerHTML = `<div class="msg-error">${err.message}</div>`;
    }
  }

  function renderNotes(notes) {
    const listEl = document.getElementById("notesList");
    if (!notes.length) { listEl.innerHTML = `<div class="msg-empty">No notes yet.</div>`; return; }
    listEl.innerHTML = notes.map(n => `
      <div class="note-item">
        <div class="meta">${n.created_at} — ${n.officer}</div>
        <div class="text">${n.note}</div>
      </div>`).join("");
  }

  // ---------- PDF ----------
  document.getElementById("pdfBtn").addEventListener("click", async () => {
    const crimeNo = document.getElementById("pdfCrimeNo").value.trim();
    const msg = document.getElementById("pdfMsg");
    if (!crimeNo) return;
    msg.textContent = "Generating…";
    try {
      const res = await authFetch(`/api/pdf/${encodeURIComponent(crimeNo)}`);
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Could not generate PDF");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `${crimeNo}_report.pdf`;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      msg.textContent = "Downloaded.";
    } catch (err) {
      msg.innerHTML = `<span class="msg-error">${err.message}</span>`;
    }
  });
}

// ---------------- Heatmap ----------------
async function loadHeatmap() {
  const el = document.getElementById("heatmapMap");
  if (!el) return;
  const map = L.map(el, { attributionControl: false }).setView([12.97, 77.6], 12);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 18 }).addTo(map);

  const statusColor = { "open": "#e07a58", "under-investigation": "#e0bc4a", "closed": "#3fa889" };
  try {
    const res = await authFetch("/api/heatmap");
    const rows = await res.json();
    rows.forEach(r => {
      L.circleMarker([r.lat, r.lng], {
        radius: 6, color: statusColor[r.status] || "#999",
        fillColor: statusColor[r.status] || "#999", fillOpacity: 0.75, weight: 1
      }).bindPopup(`<b>${r.crime_no}</b><br>${r.type}<br>${r.district} — ${r.status}`).addTo(map);
    });
  } catch (err) {
    console.error(err);
  }
}

// ---------------- Network graph ----------------
async function loadGraph() {
  const svgEl = document.getElementById("relGraph");
  if (!svgEl) return;
  try {
    const res = await authFetch("/api/graph");
    const data = await res.json();
    const kindColor = { case: "#c9a227", officer: "#c23a5a", accused: "#e07a58", victim: "#3fa889" };

    const W = svgEl.clientWidth || 700, H = 440;
    const svg = d3.select("#relGraph").attr("viewBox", [0, 0, W, H]);

    const sim = d3.forceSimulation(data.nodes)
      .force("link", d3.forceLink(data.edges).id(d => d.id).distance(60).strength(0.5))
      .force("charge", d3.forceManyBody().strength(-90))
      .force("center", d3.forceCenter(W / 2, H / 2))
      .force("collide", d3.forceCollide(10));

    const link = svg.append("g").selectAll("line").data(data.edges).join("line")
      .attr("stroke", "#3a2e2c").attr("stroke-width", 1);

    const node = svg.append("g").selectAll("circle").data(data.nodes).join("circle")
      .attr("r", d => d.kind === "case" ? 7 : 5)
      .attr("fill", d => kindColor[d.kind] || "#888")
      .call(d3.drag()
        .on("start", (e, d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
        .on("drag", (e, d) => { d.fx = e.x; d.fy = e.y; })
        .on("end", (e, d) => { if (!e.active) sim.alphaTarget(0); d.fx = null; d.fy = null; }));

    node.append("title").text(d => d.label);

    sim.on("tick", () => {
      link.attr("x1", d => d.source.x).attr("y1", d => d.source.y)
          .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
      node.attr("cx", d => d.x).attr("cy", d => d.y);
    });
  } catch (err) {
    console.error(err);
  }
}

// ---------------- Analytics ----------------
async function loadAnalytics() {
  const canvas = document.getElementById("chartMonthly");
  if (!canvas) return;
  Chart.defaults.color = "#b5a89f";
  Chart.defaults.font.family = "'IBM Plex Sans',sans-serif";

  try {
    const res = await authFetch("/api/analytics");
    const data = await res.json();

    new Chart(document.getElementById("chartMonthly"), {
      type: "line",
      data: { labels: data.monthly.labels, datasets: [{ data: data.monthly.values, borderColor: "#c9a227", backgroundColor: "rgba(201,162,39,.1)", fill: true, tension: .3 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    });
    new Chart(document.getElementById("chartType"), {
      type: "bar",
      data: { labels: data.by_type.labels, datasets: [{ data: data.by_type.values, backgroundColor: "#9a2a44", borderRadius: 4 }] },
      options: { responsive: true, maintainAspectRatio: false, indexAxis: "y", plugins: { legend: { display: false } } }
    });
    new Chart(document.getElementById("chartDistrict"), {
      type: "bar",
      data: { labels: data.by_district.labels, datasets: [{ data: data.by_district.values, backgroundColor: "#c23a5a", borderRadius: 4 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    });
    new Chart(document.getElementById("chartStatus"), {
      type: "doughnut",
      data: { labels: data.by_status.labels, datasets: [{ data: data.by_status.values, backgroundColor: ["#e07a58", "#e0bc4a", "#3fa889"] }] },
      options: { responsive: true, maintainAspectRatio: false }
    });
  } catch (err) {
    console.error(err);
  }
}
